import { Component, HostListener, signal, inject } from '@angular/core';
import { Router, NavigationEnd, RouterLink, RouterLinkActive } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
const links=[{label:'Home',path:'/'},{label:'Services',path:'/services'},{label:'About',path:'/about'},{label:'Contact',path:'/contact'}];
@Component({selector:'nx-navbar', imports:[RouterLink,RouterLinkActive], template:`
<header class="dark"><nav class="wrap nav" aria-label="Main navigation">
<a class="brand" routerLink="/" (click)="close()">NEXORA.</a>
<button class="menu" type="button" [attr.aria-expanded]="open()" aria-controls="nav-links" (click)="open.set(!open())">{{open()?'Close':'Menu'}}</button>
<div class="nav-links" [class.open]="open()" id="nav-links">@for(link of links;track link.path){<a [routerLink]="link.path" routerLinkActive="active" [routerLinkActiveOptions]="{exact:link.path==='/'}" ariaCurrentWhenActive="page" (click)="close()">{{link.label}}</a>}</div>
<a class="btn nav-cta" routerLink="/contact">Let’s talk ↗</a></nav></header>`})
export class NavbarComponent {
 readonly links=links; readonly open=signal(false); private router=inject(Router);
 constructor(){this.router.events.pipe(takeUntilDestroyed()).subscribe(e=>{if(e instanceof NavigationEnd)this.close();});}
 @HostListener('document:keydown.escape') close(){this.open.set(false);}
}
@Component({selector:'nx-footer',imports:[RouterLink],template:`<footer class="dark"><div class="wrap foot"><div><a class="brand" routerLink="/">NEXORA.</a><p>Technology with purpose.</p></div><div><nav aria-label="Footer navigation">@for(link of links;track link.path){<a [routerLink]="link.path">{{link.label}}</a>}</nav><small>Concept website • Portfolio project</small></div></div></footer>`})
export class FooterComponent {readonly links=links;}
