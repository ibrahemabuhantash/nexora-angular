import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
@Component({selector:'nx-success',imports:[RouterLink],template:`<section class="section white"><div class="wrap stack"><p class="eyebrow success">INQUIRY DEMO COMPLETE</p><h1 class="success-heading">Thanks for reaching out.</h1><p class="body-large muted">This is a demonstration of the confirmation state. No message was sent.</p><a class="btn" routerLink="/">Back to home →</a></div></section>`})
export class SuccessComponent{}
