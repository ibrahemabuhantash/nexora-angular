import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent, FooterComponent } from './shared/layout.component';
@Component({selector:'nx-root', imports:[RouterOutlet, NavbarComponent, FooterComponent], template:`<a class="skip" href="#main-content">Skip to content</a><nx-navbar/><main id="main-content" tabindex="-1"><router-outlet/></main><nx-footer/>`})
export class AppComponent {}
