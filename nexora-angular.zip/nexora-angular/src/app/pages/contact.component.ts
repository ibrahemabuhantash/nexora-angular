import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IntroComponent } from '../shared/content.component';
@Component({selector:'nx-contact',imports:[ReactiveFormsModule,IntroComponent],template:`
<nx-intro eyebrow="GET IN TOUCH" heading="Let’s talk about your next project." description="Share what you’re building and the challenges you want to solve."/>
<section class="section"><div class="wrap"><form class="project-form stack" [formGroup]="form" (ngSubmit)="submit()" novalidate><h3>Tell us about your project</h3>
<div class="field"><label for="name">Full name</label><input id="name" autocomplete="name" placeholder="Enter your name" formControlName="name" required [attr.aria-invalid]="invalid('name')" aria-describedby="name-help"><small id="name-help" [class.error]="invalid('name')">{{invalid('name')?'Please enter your name.':'Required'}}</small></div>
<div class="field"><label for="email">Work email</label><input id="email" type="email" autocomplete="email" placeholder="you@company.com" formControlName="email" required [attr.aria-invalid]="invalid('email')" aria-describedby="email-help"><small id="email-help" [class.error]="invalid('email')">{{invalid('email')?'Please enter a valid email.':'Required'}}</small></div>
<div class="field"><label for="company">Company</label><input id="company" autocomplete="organization" placeholder="Company name" formControlName="company" aria-describedby="company-help"><small id="company-help">Optional</small></div>
<div class="field"><label for="type">Project type</label><select id="type" formControlName="type" required [attr.aria-invalid]="invalid('type')" aria-describedby="type-help"><option value="">Website / Mobile app / Other</option>@for(t of types;track t){<option [value]="t">{{t}}</option>}</select><small id="type-help" [class.error]="invalid('type')">{{invalid('type')?'Choose a project type.':'Required'}}</small></div>
<div class="field"><label for="details">Project details</label><textarea id="details" placeholder="What would you like to build?" formControlName="details" required [attr.aria-invalid]="invalid('details')" aria-describedby="details-help"></textarea><small id="details-help" [class.error]="invalid('details')">{{invalid('details')?'Add at least 10 characters.':'Required'}}</small></div>
<button class="btn" type="submit" [disabled]="submitting()">{{submitting()?'Checking…':'Send inquiry →'}}</button>@if(attempted() && form.invalid){<p class="error" role="alert">Please correct the highlighted fields.</p>}<p class="form-note">Prototype only — no data is submitted.</p></form></div></section>`})
export class ContactComponent {
 private fb=inject(FormBuilder); private router=inject(Router); private route=inject(ActivatedRoute);
 readonly attempted=signal(false); readonly submitting=signal(false);
 readonly types=['Website','Mobile app','Website / Mobile app','Digital transformation','UI/UX design','Other'];
 readonly form=this.fb.nonNullable.group({name:['',[Validators.required,Validators.pattern(/\S/)]],email:['',[Validators.required,Validators.email]],company:[''],type:['',Validators.required],details:['',[Validators.required,Validators.minLength(10),Validators.pattern(/\S/)] ]});
 constructor(){const value=this.route.snapshot.queryParamMap.get('service');if(value && this.types.includes(value))this.form.controls.type.setValue(value);}
 invalid(key:keyof typeof this.form.controls){const control=this.form.controls[key];return control.invalid&&(control.touched||this.attempted());}
 async submit(){if(this.submitting())return;this.attempted.set(true);this.form.markAllAsTouched();if(this.form.invalid){document.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus();return;}this.submitting.set(true);try{await this.router.navigate(['/contact/success']);}finally{this.submitting.set(false);}}
}
