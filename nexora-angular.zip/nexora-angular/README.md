# NEXORA — Figma to Angular

A corporate website concept for a fictional digital solutions studio. The source is the NEXORA Figma project: https://www.figma.com/design/Qofz0LKOwWLGLbsp4u0UR6

## Run on Windows (PowerShell / VS Code)

1. Install Node.js 22 LTS (22.12 or later on the 22.x line).
2. Extract the ZIP and open the `nexora-angular` folder in VS Code.
3. In the integrated terminal execute:

```powershell
npm install
npm start
```

Visit http://localhost:4200. Use Ctrl+C to stop the server. No global Angular CLI installation is required.

To build for deployment:

```powershell
npm run build
```

Publish `dist/nexora/browser`. Vercel and Netlify configurations include route fallbacks for direct links and refreshes.

## Architecture

- Angular 20.3, standalone components and lazy-loaded routes.
- `src/app/pages/`: Home, Services, About, Contact, Success.
- `src/app/shared/`: navigation/footer, service grid, page intro, process, CTA.
- `src/styles.css`: CSS custom properties mapped to Figma variable names, responsive styling, hover/focus, form/error styles.
- Angular Reactive Forms: local validation and demo confirmation. Service cards preselect project type.
- Screens adapt using CSS, with desktop, tablet and mobile layouts. Responsive layout is not an exact pixel-for-pixel recreation at every size; navigation, keyboard focus and readable form borders are implementation decisions.

## Scope and verification

The design is English only. This is a frontend concept, not a deployed service. No contact data is sent or saved. The hero bars are illustrative, not metrics. Do not connect a real backend without server-side validation, spam protection and privacy requirements.

The environment could not resolve the npm registry, so dependencies could not be installed, the Angular compiler/build was not run, and no lockfile was generated. Ten TypeScript files passed syntax transpilation checks. The separately supplied offline HTML preview uses the same layout/CSS and was browser-tested at 1440, 768, 390 and 320 pixels, including service selection, demo form confirmation, return home and the mobile menu. This is not a test of Angular runtime behavior. The offline preview uses the available system fallback if Inter is absent; Angular installs Inter through npm.

After `npm install`, please run `npm run build`, open `npm start` and exercise all routes and the form before publishing. Commit the generated package-lock.json for reproducible builds.
