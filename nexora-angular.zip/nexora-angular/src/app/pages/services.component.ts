import { Component } from '@angular/core';
import { IntroComponent, ServiceGridComponent, ProcessComponent, CtaComponent } from '../shared/content.component';
@Component({selector:'nx-services',imports:[IntroComponent,ServiceGridComponent,ProcessComponent,CtaComponent],template:`<nx-intro eyebrow="OUR EXPERTISE" heading="Solutions built for real business needs." description="From interfaces to software, we bring clarity to digital projects."/><section class="section"><div class="wrap stack"><h2>Explore our services</h2><nx-service-grid/></div></section><nx-process/><nx-cta/>`})
export class ServicesComponent{}
