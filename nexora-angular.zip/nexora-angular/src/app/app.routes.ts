import { Routes } from '@angular/router';
export const routes: Routes = [
 {path:'', title:'NEXORA — Digital Solutions', loadComponent:()=>import('./pages/home.component').then(m=>m.HomeComponent)},
 {path:'services', title:'Services | NEXORA', loadComponent:()=>import('./pages/services.component').then(m=>m.ServicesComponent)},
 {path:'about', title:'About | NEXORA', loadComponent:()=>import('./pages/about.component').then(m=>m.AboutComponent)},
 {path:'contact', title:'Contact | NEXORA', loadComponent:()=>import('./pages/contact.component').then(m=>m.ContactComponent)},
 {path:'contact/success', title:'Inquiry demo | NEXORA', loadComponent:()=>import('./pages/success.component').then(m=>m.SuccessComponent)},
 {path:'**', redirectTo:''}
];
